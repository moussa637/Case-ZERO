/* CASE ZERO | القضية صفر — Stage 1+2 client (individual investigation).
   Layers: Store (persistence, swap for server later) -> Model helpers -> Views.
   Players' data lives ONLY in this browser's localStorage (no cross-device sync, no cloud backup). */
(function(){
'use strict';

/* ---------- utils ---------- */
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s==null?'':s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = (p='id') => p + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
const fmtDT = ts => ts ? new Date(ts).toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'short'}) : '—';
const clone = o => JSON.parse(JSON.stringify(o));
const LOGO = `<svg viewBox="0 0 100 100" role="img" aria-label="شعار CASE ZERO"><circle cx="42" cy="42" r="28" fill="none" stroke="#AEB4BE" stroke-width="6"/><line x1="63" y1="63" x2="90" y2="90" stroke="#A51D2D" stroke-width="9" stroke-linecap="round"/><path d="M29 30h26L29 54h26" fill="none" stroke="#C6A15B" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"/></svg>`;

/* ---------- persistence layer ---------- */
const Store = {
  KEY:'czv1:data', PREV:'czv1:prev', data:null, failSim:false, timer:null, lastSaved:null, dirty:false,
  defaults(){ return {v:1, user:{id:uid('user'), name:'محقق'}, settings:{theme:'dark',glow:35,fs:16,reduceMotion:false,contrast:'normal'}, introSeen:false, investigations:{}, multiplayerSessions:{}, onlineSessions:{}}; },
  valid(d){ return d && typeof d==='object' && d.v===1 && d.user && d.settings && d.investigations && typeof d.investigations==='object'; },
  load(){
    for(const k of [this.KEY, this.PREV]){
      try{ const raw = localStorage.getItem(k); if(!raw) continue; const d = JSON.parse(raw);
        if(this.valid(d)){ this.data = Object.assign(this.defaults(), d); this.data.settings = Object.assign(this.defaults().settings, d.settings); this.data.multiplayerSessions = d.multiplayerSessions || {}; this.data.onlineSessions = d.onlineSessions || {}; return k===this.KEY ? 'ok':'recovered'; }
      }catch(e){}
    }
    this.data = this.defaults(); return 'new';
  },
  schedule(){ this.dirty = true; setSave('pending'); clearTimeout(this.timer); this.timer = setTimeout(()=>this.flush(), 500); },
  flush(){
    clearTimeout(this.timer);
    try{
      if(this.failSim) throw new Error('simulated failure');
      const prev = localStorage.getItem(this.KEY);
      const json = JSON.stringify(this.data);
      localStorage.setItem(this.KEY, json);
      if(prev) localStorage.setItem(this.PREV, prev);
      this.dirty = false; this.lastSaved = Date.now(); setSave('saved');
      return true;
    }catch(e){ setSave('error'); return false; }
  }
};
function setSave(state){
  const el = $('#saveInd'); if(!el) return;
  if(state==='pending') el.textContent = '… تغييرات غير محفوظة';
  else if(state==='saved') el.textContent = '✔ تم الحفظ محليًا ' + new Date(Store.lastSaved).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'});
  else if(state==='error'){ el.innerHTML = '⚠ فشل الحفظ <button class="btn small" id="retrySave">إعادة المحاولة</button>'; const b=$('#retrySave'); if(b) b.onclick=()=>{ if(Store.flush()) toast('تم الحفظ'); else toast('ما زال الحفظ يفشل'); }; toast('تعذّر حفظ التقدم. ستبقى التغييرات في الصفحة؛ اضغط إعادة المحاولة.'); }
}
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toast.t); toast.t=setTimeout(()=>t.classList.remove('show'),3200); }

/* ---------- model ---------- */
const CASES = () => window.PLAYER_CASES || [];
const getCase = id => CASES().find(c=>c.id===id);
const getInv = id => Store.data.investigations[id] || null;
function ensureInv(caseId){
  let i = getInv(caseId);
  if(!i){
    i = {id:uid('inv'), caseId, userId:Store.data.user.id, startedAt:Date.now(), lastActivity:Date.now(),
      docs:{}, board:{items:[], links:[], zoom:1}, notes:[], hyps:[], timeline:[], checkpoints:[],
      report:{draft:emptyReport(), submissions:[]}};
    Store.data.investigations[caseId] = i; Store.schedule();
  }
  return i;
}
function emptyReport(){ return {conclusion:'',suspect:'',supporting:[],conflicting:[],timeline:'',explanation:'',questions:'',confidence:50,observations:'',basedOn:null}; }
function touch(caseId){ const i=getInv(caseId); if(i){ i.lastActivity = Date.now(); Store.schedule(); } }
function caseStatus(c){ const i=getInv(c.id); if(!i) return 'available'; return i.report.submissions.length ? 'completed' : 'in_progress'; }
const STATUS_LABEL = {available:'متاحة', in_progress:'قيد التحقيق', completed:'مكتملة'};
const CLS = {documented:'دليل موثق', testimony:'شهادة', unverified:'معلومة غير مؤكدة', contradiction:'تناقض محتمل', hypothesis:'فرضية اللاعب', conclusion:'استنتاج اللاعب'};
const CERT = {confirmed:'حدث مؤكد', reported:'حدث مُبلَّغ عنه', estimated:'حدث مقدَّر', unknown:'الوقت غير معروف'};
const HSTATUS = {investigating:'قيد التحقيق', supported:'مدعومة بالأدلة', conflicting:'ظهرت أدلة متعارضة', rejected:'استبعدها اللاعب', included:'مضمّنة في التقرير النهائي'};
const docTitle = (c,id) => { const d=c.documents.find(x=>x.id===id); return d ? `${d.no} — ${d.title}` : '(مستند غير موجود)'; };

/* ---------- settings ---------- */
function applySettings(){
  const s = Store.data.settings, r = document.documentElement;
  // CASE ZERO is intentionally dark-mode only; preserve this even for older saved settings.
  s.theme = 'dark';
  r.dataset.theme = 'dark'; r.dataset.contrast = s.contrast;
  r.style.setProperty('--glow', (s.glow/100).toString()); r.style.setProperty('--fs', s.fs+'px');
  document.body.classList.toggle('reduce-motion', !!s.reduceMotion || matchMedia('(prefers-reduced-motion: reduce)').matches);
}

/* ---------- routing ---------- */
const NAV = [
  ['home','الشاشة الرئيسية'],['archive','أرشيف القضايا'],['resume','متابعة التحقيق'],['completed','القضايا المكتملة'],
  ['multi','التحقيق الجماعي'],['lab','مختبر القضية صفر'],['profile','ملف المحقق'],['settings','الإعدادات']
];
let ctx = {prev:null};
function go(h){ if(location.hash === '#'+h) route(); else location.hash = h; }
function route(){
  const parts = location.hash.replace(/^#\/?/,'').split('/').filter(Boolean);
  const top = parts[0] || 'home';
  if(top!=='multi' && typeof multiPoll!=='undefined' && multiPoll){ clearInterval(multiPoll); multiPoll=null; }
  if(top==='case' && parts[2] && parts[2]!=='doc') ctx.prevSec = parts[2];
  renderNav(top);
  const v = $('#view'); v.scrollTop = 0; window.scrollTo(0,0);
  try{
    if(top==='home') viewHome(v);
    else if(top==='archive') viewArchive(v, null);
    else if(top==='completed') viewArchive(v, 'completed');
    else if(top==='resume') viewResume(v);
    else if(top==='multi') viewMulti(v);
    else if(top==='lab') viewLab(v);
    else if(top==='profile') viewProfile(v);
    else if(top==='settings') viewSettings(v);
    else if(top==='case') viewCase(v, parts);
    else viewPlaceholder(v,'الصفحة غير موجودة','تعذّر العثور على هذه الصفحة.');
  }catch(e){ console.error(e); v.innerHTML = `<div class="card"><h2>حدث خطأ غير متوقع</h2><p class="hint">${esc(e.message)}</p><a class="btn" href="#/home">العودة إلى الرئيسية</a></div>`; }
  v.focus({preventScroll:true});
}
function renderNav(top){
  $('#nav').innerHTML = NAV.map(([k,l])=>`<button data-k="${k}" class="${(k===top||(top==='case'&&k==='archive'))?'active':''}" ${k===top?'aria-current="page"':''}>${l}</button>`).join('');
  $$('#nav button').forEach(b=> b.onclick = ()=> go('/'+b.dataset.k));
}
function viewPlaceholder(v,title,msg){
  v.innerHTML = `<div class="card"><h2>${esc(title)}</h2><div class="warn">لم يُفعَّل بعد</div><p>${esc(msg)}</p><a class="btn" href="#/home">العودة</a></div>`;
}

/* ---------- home ---------- */
function viewHome(v){
  const items = [['archive','أرشيف القضايا','تصفح القضايا واختر تحقيقًا'],['resume','متابعة التحقيق','استكمل آخر تحقيق'],['completed','القضايا المكتملة','التحقيقات التي سلّمت تقريرها'],['multi','التحقيق الجماعي','تعاون أو منافسة داخل جلسة تحقيق'],['lab','مختبر القضية صفر','مراجعة القضايا وإنشاء المسودات بالذكاء الاصطناعي'],['profile','ملف المحقق','بياناتك وإحصاءاتك'],['settings','الإعدادات','المظهر والحفظ والبيانات']];
  v.innerHTML = `<section class="hero">${LOGO}<h1>CASE ZERO | القضية صفر</h1><p>كل ملف يخفي حقيقة. ليست كل حقيقة كما تبدو.</p></section>
  <div class="tiles">${items.map(([k,t,s])=>`<button class="tile" data-k="${k}"><h3>${t}</h3><span>${s}</span></button>`).join('')}</div>`;
  $$('.tile',v).forEach(b=> b.onclick = ()=> go('/'+b.dataset.k));
}

/* ---------- archive ---------- */
const AF = {q:'', diff:'', cat:'', status:'', sort:'number'};
function viewArchive(v, preset){
  AF.status = preset || '';
  const cases = CASES();
  if(!cases.length){ v.innerHTML = `<div class="card"><h2>أرشيف القضايا</h2><p>لا توجد قضايا منشورة حاليًا.</p></div>`; return; }
  const diffs = [...new Set(cases.map(c=>c.difficulty))], cats = [...new Set(cases.map(c=>c.category))];
  v.innerHTML = `<h2>${preset==='completed'?'القضايا المكتملة':'أرشيف القضايا'}</h2>
  <div class="toolbar">
    <input type="search" id="fq" placeholder="بحث بالعنوان أو الرقم أو الوصف" aria-label="بحث" value="${esc(AF.q)}">
    <select id="fd" aria-label="الصعوبة"><option value="">كل المستويات</option>${diffs.map(d=>`<option ${AF.diff===d?'selected':''}>${esc(d)}</option>`).join('')}</select>
    <select id="fc" aria-label="التصنيف"><option value="">كل التصنيفات</option>${cats.map(d=>`<option ${AF.cat===d?'selected':''}>${esc(d)}</option>`).join('')}</select>
    <select id="fs" aria-label="الحالة"><option value="">كل الحالات</option>${Object.entries(STATUS_LABEL).map(([k,l])=>`<option value="${k}" ${AF.status===k?'selected':''}>${l}</option>`).join('')}</select>
    <select id="fo" aria-label="الترتيب"><option value="number" ${AF.sort==='number'?'selected':''}>الترتيب: رقم القضية</option><option value="title" ${AF.sort==='title'?'selected':''}>الترتيب: العنوان</option><option value="activity" ${AF.sort==='activity'?'selected':''}>الترتيب: آخر نشاط</option><option value="time" ${AF.sort==='time'?'selected':''}>الترتيب: الزمن التقديري</option></select>
  </div><div id="cardsHost"></div>`;
  const draw = ()=>{
    const q = AF.q.trim().toLowerCase();
    let list = cases.filter(c => (!q || [c.number,c.title,c.description].join(' ').toLowerCase().includes(q)) && (!AF.diff||c.difficulty===AF.diff) && (!AF.cat||c.category===AF.cat) && (!AF.status||caseStatus(c)===AF.status));
    const act = c => (getInv(c.id)||{}).lastActivity || 0;
    list.sort((a,b)=> AF.sort==='title' ? a.title.localeCompare(b.title,'ar') : AF.sort==='activity' ? act(b)-act(a) : AF.sort==='time' ? (a.estimatedMinutes||1e9)-(b.estimatedMinutes||1e9) : a.number.localeCompare(b.number));
    $('#cardsHost').innerHTML = list.length ? `<div class="grid">${list.map(c=>{ const st=caseStatus(c), i=getInv(c.id); return `<article class="card">
      <div class="case-cover" aria-hidden="true"><span>CASE</span><b>${esc(c.number)}</b></div>
      <div class="hint">${esc(c.number)}</div><h3>${esc(c.title)}</h3>
      <div><span class="tag">${esc(c.category)}</span><span class="tag gold">${esc(c.difficulty)}</span><span class="tag ${st==='completed'?'blue':st==='in_progress'?'red':''}">${STATUS_LABEL[st]}</span></div>
      <p>${esc(c.description)}</p>
      <p class="hint">${c.estimatedMinutes?`الزمن التقديري: ${c.estimatedMinutes} دقيقة`:''}${i?` · آخر نشاط: ${fmtDT(i.lastActivity)}`:''}</p>
      <button class="btn" data-open="${esc(c.id)}">${st==='available'?'فتح الملف':st==='in_progress'?'استئناف التحقيق':'مراجعة التحقيق'}</button></article>`; }).join('')}</div>` : `<div class="card"><p>لا توجد قضايا تطابق هذه المعايير.</p><button class="btn ghost" id="clearF">مسح الفلاتر</button></div>`;
    $$('[data-open]').forEach(b=> b.onclick = ()=> go('/case/'+b.dataset.open+'/info'));
    const cf=$('#clearF'); if(cf) cf.onclick=()=>{ Object.assign(AF,{q:'',diff:'',cat:'',status:'',sort:'number'}); viewArchive(v, null); };
  };
  $('#fq').oninput = e=>{AF.q=e.target.value; draw();};
  $('#fd').onchange = e=>{AF.diff=e.target.value; draw();};
  $('#fc').onchange = e=>{AF.cat=e.target.value; draw();};
  $('#fs').onchange = e=>{AF.status=e.target.value; draw();};
  $('#fo').onchange = e=>{AF.sort=e.target.value; draw();};
  draw();
}
function viewResume(v){
  const list = Object.values(Store.data.investigations).filter(i=>getCase(i.caseId) && !i.report.submissions.length).sort((a,b)=>b.lastActivity-a.lastActivity);
  if(!list.length){ v.innerHTML = `<div class="card"><h2>متابعة التحقيق</h2><p>لا يوجد تحقيق قيد التنفيذ. ابدأ من الأرشيف.</p><a class="btn" href="#/archive">أرشيف القضايا</a></div>`; return; }
  go('/case/'+list[0].caseId+'/info');
}

/* ---------- case workspace ---------- */
const SECTIONS = [['info','نظرة عامة'],['docs','الأدلة والمستندات'],['board','لوحة الأدلة'],['notes','الملاحظات'],['hyps','الفرضيات'],['timeline','التسلسل الزمني'],['report','التقرير النهائي']];
function viewCase(v, parts){
  const c = getCase(parts[1]);
  if(!c){ viewPlaceholder(v,'القضية غير موجودة','لا توجد قضية بهذا المعرّف.'); return; }
  const sec = parts[2] || 'info';
  const i = ensureInv(c.id);
  ctx.caseId = c.id;
  const tabs = `<div class="tabs" role="tablist" aria-label="أقسام التحقيق">${SECTIONS.map(([k,l])=>`<button role="tab" data-sec="${k}" class="${(sec===k||(sec==='doc'&&k==='docs'))?'active':''}" aria-selected="${sec===k}">${l}</button>`).join('')}</div>`;
  v.innerHTML = `<div class="row"><h2>${esc(c.number)} — ${esc(c.title)}</h2><span class="spacer"></span><a class="btn ghost small" href="#/archive">العودة إلى الأرشيف</a></div>${tabs}<div id="sec"></div>`;
  $$('[data-sec]',v).forEach(b=> b.onclick = ()=> go(`/case/${c.id}/${b.dataset.sec}`));
  const host = $('#sec');
  if(sec==='info') secInfo(host,c,i);
  else if(sec==='docs') secDocs(host,c,i);
  else if(sec==='doc') secDoc(host,c,i,parts[3]);
  else if(sec==='board') secBoard(host,c,i);
  else if(sec==='notes') secNotes(host,c,i);
  else if(sec==='hyps') secHyps(host,c,i);
  else if(sec==='timeline') secTimeline(host,c,i);
  else if(sec==='report') secReport(host,c,i);
  else host.innerHTML = '<div class="card">القسم غير موجود.</div>';
}

/* overview + checkpoints */
function secInfo(h,c,i){
  const opened = Object.values(i.docs).filter(d=>d.opened).length;
  h.innerHTML = `<div class="card"><p>${esc(c.description)}</p>
    <p><span class="tag">${esc(c.category)}</span><span class="tag gold">${esc(c.difficulty)}</span><span class="tag ${i.report.submissions.length?'blue':'red'}">${STATUS_LABEL[caseStatus(c)]}</span></p>
    <p class="hint">بدأ التحقيق: ${fmtDT(i.startedAt)} · آخر نشاط: ${fmtDT(i.lastActivity)}</p></div>
    <h3>الشخصيات المذكورة في الملف</h3><div class="grid">${c.suspects.map(s=>`<div class="card"><b>${esc(s.name)}</b><div class="hint">${esc(s.role)}</div></div>`).join('')}</div>
    <h3>التقدم</h3><div class="card"><p>مستندات فُتحت: ${opened} / ${c.documents.length} · عناصر على اللوحة: ${i.board.items.length} · ملاحظات: ${i.notes.length} · فرضيات: ${i.hyps.length} · أحداث زمنية: ${i.timeline.length} · تقارير مُسلَّمة: ${i.report.submissions.length}</p>
    <button class="btn" id="goDocs">${opened?'متابعة قراءة المستندات':'بدء الفحص'}</button></div>
    <h3>نقاط الحفظ</h3><div class="card"><p class="hint">نقطة الحفظ نسخة كاملة من لوحتك وملاحظاتك وفرضياتك وجدولك ومسودة تقريرك. تُحفظ في هذا المتصفح فقط.</p>
    <div class="row"><input type="text" id="cpName" placeholder="اسم نقطة الحفظ (اختياري)" aria-label="اسم نقطة الحفظ"><button class="btn" id="cpAdd">إنشاء نقطة حفظ</button></div>
    <div id="cpList"></div></div>`;
  $('#goDocs').onclick = ()=> go(`/case/${c.id}/docs`);
  const drawCP = ()=>{ $('#cpList').innerHTML = i.checkpoints.length ? `<table><tbody>${i.checkpoints.map(k=>`<tr><td>${esc(k.name)}<div class="hint">${fmtDT(k.at)}</div></td><td><button class="btn small ghost" data-r="${k.id}">استعادة</button> <button class="btn small ghost" data-x="${k.id}">حذف</button></td></tr>`).join('')}</tbody></table>` : '<p class="hint">لا توجد نقاط حفظ.</p>';
    $$('[data-r]').forEach(b=> b.onclick=()=>{ const k=i.checkpoints.find(x=>x.id===b.dataset.r); if(!k||!confirm('استعادة هذه النقطة ستستبدل لوحتك وملاحظاتك وفرضياتك وجدولك ومسودة التقرير الحالية. المتابعة؟')) return; const s=clone(k.snap); Object.assign(i,{docs:s.docs,board:s.board,notes:s.notes,hyps:s.hyps,timeline:s.timeline}); i.report.draft=s.draft; touch(c.id); toast('تمت الاستعادة'); secInfo(h,c,i); });
    $$('[data-x]').forEach(b=> b.onclick=()=>{ if(!confirm('حذف نقطة الحفظ؟')) return; i.checkpoints = i.checkpoints.filter(x=>x.id!==b.dataset.x); touch(c.id); drawCP(); });
  };
  $('#cpAdd').onclick = ()=>{ const n=$('#cpName').value.trim() || 'نقطة حفظ '+(i.checkpoints.length+1); i.checkpoints.push({id:uid('cp'),name:n,at:Date.now(),snap:clone({docs:i.docs,board:i.board,notes:i.notes,hyps:i.hyps,timeline:i.timeline,draft:i.report.draft})}); touch(c.id); toast('تم إنشاء نقطة الحفظ'); $('#cpName').value=''; drawCP(); };
  drawCP();
}

/* documents list */
function secDocs(h,c,i){
  h.innerHTML = `<p class="hint">هذه مواد التحقيق الخام. لا تحتوي على استنتاجات جاهزة.</p>
  <div class="grid">${c.documents.map(d=>{ const st=i.docs[d.id]||{}; return `<article class="card"><div class="hint">${esc(d.no)} · ${esc(d.type)} · ${esc(d.date)}</div><h3>${esc(d.title)}</h3>
    <p>${st.opened?'<span class="tag blue">تمت قراءته</span>':'<span class="tag">لم يُفتح</span>'}${st.flag?'<span class="tag gold">للمراجعة لاحقًا</span>':''}</p>
    <button class="btn" data-d="${d.id}">فتح المستند</button></article>`; }).join('')}</div>`;
  $$('[data-d]',h).forEach(b=> b.onclick=()=> go(`/case/${c.id}/doc/${b.dataset.d}`));
}

/* document viewer */
function secDoc(h,c,i,docId){
  const idx = c.documents.findIndex(d=>d.id===docId);
  if(idx<0){ h.innerHTML='<div class="card">المستند غير موجود.<br><a class="btn" href="#/case/'+c.id+'/docs">العودة</a></div>'; return; }
  const d = c.documents[idx];
  const st = i.docs[d.id] = i.docs[d.id] || {}; if(!st.opened){ st.opened = Date.now(); touch(c.id); }
  const zoom = ctx.zoom || 1;
  const onBoard = i.board.items.some(x=>x.ref===d.id);
  const notes = i.notes.filter(n=>n.ref===d.id);
  h.innerHTML = `<div class="row"><button class="btn ghost small" id="back">← ${ctx.prev && /board|hyps|timeline|report|notes/.test(ctx.prev)?'العودة إلى القسم السابق':'قائمة المستندات'}</button><span class="spacer"></span>
    <button class="btn ghost small" id="zm" aria-label="تصغير الخط">أ−</button><button class="btn ghost small" id="zp" aria-label="تكبير الخط">أ+</button></div>
  <div class="paper" style="--zoom:${zoom}" id="paper"><div class="doc-meta">${esc(d.no)} · ${esc(d.type)} · ${esc(d.date)}</div><h3>${esc(d.title)}</h3><div>${esc(d.body)}</div></div>
  <div class="row" style="margin:12px 0">
    <button class="btn ghost" id="prevD" ${idx===0?'disabled':''}>المستند السابق</button><button class="btn ghost" id="nextD" ${idx===c.documents.length-1?'disabled':''}>المستند التالي</button><span class="spacer"></span>
    <button class="btn ghost" id="flag">${st.flag?'إزالة علامة المراجعة':'وضع علامة للمراجعة لاحقًا'}</button>
    <button class="btn" id="toBoard" ${onBoard?'disabled':''}>${onBoard?'موجود على اللوحة':'إضافة إلى لوحة الأدلة'}</button></div>
  <div class="card"><h3>ملاحظاتي على هذا المستند</h3>
    ${notes.map(n=>`<div class="hint">${fmtDT(n.updated)}</div><div>${esc(n.text)}</div><hr>`).join('')}
    <textarea id="dn" placeholder="اكتب ملاحظة خاصة مرتبطة بهذا المستند" aria-label="ملاحظة"></textarea><button class="btn" id="dnAdd">حفظ الملاحظة</button></div>`;
  $('#back').onclick = ()=> go(`/case/${c.id}/${ctx.prevSec && ctx.prevSec!=='doc' ? ctx.prevSec : 'docs'}`);
  $('#zm').onclick = ()=>{ ctx.zoom = Math.max(.8,(ctx.zoom||1)-.1); $('#paper').style.setProperty('--zoom',ctx.zoom); };
  $('#zp').onclick = ()=>{ ctx.zoom = Math.min(2,(ctx.zoom||1)+.1); $('#paper').style.setProperty('--zoom',ctx.zoom); };
  $('#prevD').onclick = ()=> go(`/case/${c.id}/doc/${c.documents[idx-1].id}`);
  $('#nextD').onclick = ()=> go(`/case/${c.id}/doc/${c.documents[idx+1].id}`);
  $('#flag').onclick = ()=>{ st.flag = !st.flag; touch(c.id); secDoc(h,c,i,docId); };
  $('#toBoard').onclick = ()=>{ addBoardDoc(c,i,d.id); toast('أُضيف إلى اللوحة'); secDoc(h,c,i,docId); };
  $('#dnAdd').onclick = ()=>{ const t=$('#dn').value.trim(); if(!t){ toast('اكتب نص الملاحظة أولًا'); return; } i.notes.unshift({id:uid('note'),text:t,ref:d.id,created:Date.now(),updated:Date.now()}); touch(c.id); secDoc(h,c,i,docId); };
}

/* ---------- evidence board ---------- */
function addBoardDoc(c,i,docId){
  if(i.board.items.some(x=>x.ref===docId)) return;
  const d = c.documents.find(x=>x.id===docId); const n = i.board.items.length;
  i.board.items.push({id:uid('bi'), kind:'doc', ref:docId, x:40+(n%6)*190, y:40+Math.floor(n/6)*150, cls:d.cls||'unverified'});
  touch(c.id);
}
function secBoard(h,c,i){
  const B = i.board; let sel = null, connectFrom = null, selLink = null;
  const narrowPortrait = matchMedia('(max-width:820px) and (orientation:portrait)').matches;
  h.innerHTML = `${narrowPortrait?'<div class="warn" style="margin-bottom:10px">يمكنك استخدام اللوحة بالوضع العمودي، لكن تدوير الجهاز إلى الأفقي يمنحك مساحة أوسع.</div>':''}
  <p class="hint">الروابط التي تنشئها تعبّر عن فرضياتك التحليلية، وليست دليلًا قاطعًا على علاقة حقيقية.</p>
  <div class="row" style="margin-bottom:8px"><button class="btn ghost small" id="zi" aria-label="تكبير اللوحة">+</button><button class="btn ghost small" id="zo" aria-label="تصغير اللوحة">−</button><button class="btn ghost small" id="zr">100%</button><span class="hint" id="zl"></span><span class="spacer"></span><span class="hint">السهمان على لوحة المفاتيح يحرّكان البطاقة المحددة · Esc يلغي الربط</span></div>
  <div class="board-wrap"><div class="board" id="board" dir="ltr" tabindex="0" aria-label="لوحة الأدلة"><div class="board-inner" id="inner"><svg id="lines"></svg></div></div>
  <div class="side card" id="side"></div></div>`;
  const board=$('#board'), inner=$('#inner'), svg=$('#lines');
  const zoom = ()=> B.zoom || 1;
  const applyZoom = ()=>{ inner.style.transform = `scale(${zoom()})`; inner.style.transformOrigin = '0 0'; $('#zl').textContent = Math.round(zoom()*100)+'%'; };
  const pinEl = id => inner.querySelector(`[data-id="${id}"]`);
  const itemTitle = it => it.kind==='doc' ? (c.documents.find(d=>d.id===it.ref)||{}).title||'؟' : it.label||'بطاقة';
  const itemSub = it => it.kind==='doc' ? (c.documents.find(d=>d.id===it.ref)||{}).no||'' : 'بطاقة حرة';
  function drawPins(){
    $$('.pin',inner).forEach(p=>p.remove());
    B.items.forEach(it=>{
      const p = document.createElement('div');
      p.className = `pin cl-${it.cls}` + (sel===it.id?' sel':'') + (connectFrom===it.id?' conn':'');
      p.dataset.id = it.id; p.tabIndex = 0; p.dir = 'rtl';
      p.style.left = it.x+'px'; p.style.top = it.y+'px';
      p.setAttribute('role','button'); p.setAttribute('aria-label', `${itemTitle(it)} — ${CLS[it.cls]}`);
      p.innerHTML = `<small class="clsbadge">${CLS[it.cls]}</small><b>${esc(itemTitle(it))}</b><span>${esc(itemSub(it))}</span>`;
      inner.appendChild(p); bindPin(p,it);
    });
    drawLines();
  }
  function center(it){ const p=pinEl(it.id); return {x:it.x+(p?p.offsetWidth:170)/2, y:it.y+(p?p.offsetHeight:60)/2}; }
  function drawLines(){
    svg.innerHTML = '';
    B.links.forEach(l=>{
      const a=B.items.find(x=>x.id===l.a), b=B.items.find(x=>x.id===l.b); if(!a||!b) return;
      const A=center(a), Bc=center(b);
      const ln = document.createElementNS('http://www.w3.org/2000/svg','line');
      ln.setAttribute('x1',A.x);ln.setAttribute('y1',A.y);ln.setAttribute('x2',Bc.x);ln.setAttribute('y2',Bc.y); ln.dataset.lid=l.id;
      if(selLink===l.id) ln.style.stroke='#C6A15B';
      ln.addEventListener('click',e=>{ e.stopPropagation(); selLink=l.id; sel=null; drawLines(); drawSide(); });
      svg.appendChild(ln);
      if(l.label){ const t=document.createElementNS('http://www.w3.org/2000/svg','text'); t.setAttribute('x',(A.x+Bc.x)/2); t.setAttribute('y',(A.y+Bc.y)/2-6); t.setAttribute('fill','#F1F1F1'); t.setAttribute('font-size','13'); t.setAttribute('text-anchor','middle'); t.setAttribute('paint-order','stroke'); t.setAttribute('stroke','#101114'); t.setAttribute('stroke-width','3'); t.textContent=l.label; svg.appendChild(t); }
    });
  }
  function bindPin(p,it){
    let drag=null;
    p.addEventListener('pointerdown',e=>{
      if(connectFrom) return;
      p.setPointerCapture(e.pointerId);
      drag = {sx:e.clientX, sy:e.clientY, ox:it.x, oy:it.y, moved:false}; p.classList.add('dragging');
    });
    p.addEventListener('pointermove',e=>{
      if(!drag) return;
      const dx=(e.clientX-drag.sx)/zoom(), dy=(e.clientY-drag.sy)/zoom();
      if(Math.abs(dx)+Math.abs(dy)>3) drag.moved=true;
      it.x = Math.max(0,Math.min(1430,Math.round(drag.ox+dx))); it.y = Math.max(0,Math.min(920,Math.round(drag.oy+dy)));
      p.style.left=it.x+'px'; p.style.top=it.y+'px'; drawLines();
    });
    const end = ()=>{ if(!drag) return; p.classList.remove('dragging'); if(drag.moved) touch(c.id); drag=null; };
    p.addEventListener('pointerup',end); p.addEventListener('pointercancel',end);
    p.addEventListener('click',e=>{
      e.stopPropagation();
      if(connectFrom && connectFrom!==it.id){
        if(!B.links.some(l=>(l.a===connectFrom&&l.b===it.id)||(l.a===it.id&&l.b===connectFrom))){ B.links.push({id:uid('lk'),a:connectFrom,b:it.id,label:''}); touch(c.id); toast('تم إنشاء الرابط. يمكنك تسميته من اللوحة الجانبية.'); }
        else toast('الرابط موجود بالفعل');
        connectFrom=null; selLink=B.links[B.links.length-1].id; sel=null; drawPins(); drawSide(); return;
      }
      sel=it.id; selLink=null; $$('.pin',inner).forEach(x=>x.classList.toggle('sel',x.dataset.id===sel)); drawSide(); drawLines();
    });
    p.addEventListener('keydown',e=>{
      const step = e.shiftKey?30:10; let m=true;
      if(e.key==='ArrowLeft') it.x=Math.max(0,it.x-step); else if(e.key==='ArrowRight') it.x=Math.min(1430,it.x+step);
      else if(e.key==='ArrowUp') it.y=Math.max(0,it.y-step); else if(e.key==='ArrowDown') it.y=Math.min(920,it.y+step);
      else if(e.key==='Enter'||e.key===' '){ p.click(); e.preventDefault(); m=false; } else m=false;
      if(m){ e.preventDefault(); p.style.left=it.x+'px'; p.style.top=it.y+'px'; drawLines(); touch(c.id); }
    });
  }
  board.addEventListener('click',()=>{ if(connectFrom) return; sel=null; selLink=null; $$('.pin',inner).forEach(x=>x.classList.remove('sel')); drawLines(); drawSide(); });
  // pan by dragging empty background
  let pan=null; board.addEventListener('pointerdown',e=>{ if(e.target===board||e.target===inner||e.target===svg){ pan={x:e.clientX,y:e.clientY,l:board.scrollLeft,t:board.scrollTop}; } });
  window.addEventListener('pointermove',panMove); window.addEventListener('pointerup',panEnd);
  function panMove(e){ if(!pan) return; board.scrollLeft=pan.l-(e.clientX-pan.x); board.scrollTop=pan.t-(e.clientY-pan.y); }
  function panEnd(){ pan=null; }
  ctx.cleanup = ()=>{ window.removeEventListener('pointermove',panMove); window.removeEventListener('pointerup',panEnd); document.removeEventListener('keydown',escKey); };
  const escKey = e=>{ if(e.key==='Escape' && connectFrom){ connectFrom=null; drawPins(); drawSide(); } };
  document.addEventListener('keydown',escKey);
  board.addEventListener('wheel',e=>{ if(e.ctrlKey){ e.preventDefault(); B.zoom=Math.max(.4,Math.min(2,zoom()+(e.deltaY<0?.1:-.1))); applyZoom(); touch(c.id); } },{passive:false});
  $('#zi').onclick=()=>{ B.zoom=Math.min(2,+(zoom()+.1).toFixed(2)); applyZoom(); touch(c.id); };
  $('#zo').onclick=()=>{ B.zoom=Math.max(.4,+(zoom()-.1).toFixed(2)); applyZoom(); touch(c.id); };
  $('#zr').onclick=()=>{ B.zoom=1; applyZoom(); touch(c.id); };

  function drawSide(){
    const s=$('#side'); const it=B.items.find(x=>x.id===sel); const lk=B.links.find(x=>x.id===selLink);
    let top = '';
    if(connectFrom){ top = `<div class="warn">وضع الربط: اختر البطاقة الثانية. <button class="btn small ghost" id="cancelConn">إلغاء</button></div>`; }
    else if(it){
      top = `<h3>${esc(itemTitle(it))}</h3><label for="clsSel">التصنيف (من اختيارك)</label>
        <select id="clsSel">${Object.entries(CLS).map(([k,l])=>`<option value="${k}" ${it.cls===k?'selected':''}>${l}</option>`).join('')}</select>
        ${it.kind==='free'?`<label for="freeTxt">نص البطاقة</label><textarea id="freeTxt">${esc(it.label||'')}</textarea>`:''}
        <div class="row" style="margin-top:8px"><button class="btn small" id="connBtn">ربط ببطاقة أخرى</button>
        ${it.kind==='doc'?'<button class="btn small ghost" id="openDoc">فتح المستند الأصلي</button>':''}
        <button class="btn small ghost" id="rmItem">إزالة من اللوحة</button></div>
        <p class="hint">الروابط: ${B.links.filter(l=>l.a===it.id||l.b===it.id).length}</p><hr>`;
    } else if(lk){
      top = `<h3>رابط</h3><p class="hint">${esc(itemTitle(B.items.find(x=>x.id===lk.a)||{}))} ⟷ ${esc(itemTitle(B.items.find(x=>x.id===lk.b)||{}))}</p>
        <label for="lkLabel">تسمية الرابط (رأيك أنت)</label><input type="text" id="lkLabel" value="${esc(lk.label)}" placeholder="مثال: ربما متعلقان بنفس الشخص">
        <button class="btn small ghost" id="rmLink" style="margin-top:8px">حذف الرابط</button><hr>`;
    }
    const unused = c.documents.filter(d=>!B.items.some(x=>x.ref===d.id));
    s.innerHTML = top + `<h3>إضافة إلى اللوحة</h3>
      ${unused.length?unused.map(d=>`<div class="row" style="margin-bottom:4px"><span style="flex:1;font-size:.85rem">${esc(d.no)} — ${esc(d.title)}</span><button class="btn small" data-add="${d.id}" aria-label="إضافة ${esc(d.title)}">+</button></div>`).join(''):'<p class="hint">كل المستندات على اللوحة.</p>'}
      <hr><label for="freeNew">بطاقة حرة (فرضية أو استنتاج)</label><input type="text" id="freeNew" placeholder="نص قصير">
      <select id="freeCls" aria-label="تصنيف البطاقة الحرة"><option value="hypothesis">فرضية اللاعب</option><option value="conclusion">استنتاج اللاعب</option><option value="unverified">معلومة غير مؤكدة</option><option value="contradiction">تناقض محتمل</option></select>
      <button class="btn small" id="addFree" style="margin-top:6px">إضافة البطاقة</button>`;
    const q=id=>$('#'+id,s);
    if(q('cancelConn')) q('cancelConn').onclick=()=>{ connectFrom=null; drawPins(); drawSide(); };
    if(q('clsSel')) q('clsSel').onchange=e=>{ it.cls=e.target.value; touch(c.id); drawPins(); };
    if(q('freeTxt')) q('freeTxt').oninput=e=>{ it.label=e.target.value; touch(c.id); const p=pinEl(it.id); if(p) p.querySelector('b').textContent=it.label||'بطاقة'; };
    if(q('connBtn')) q('connBtn').onclick=()=>{ connectFrom=it.id; drawPins(); drawSide(); };
    if(q('openDoc')) q('openDoc').onclick=()=>{ ctx.prevSec='board'; go(`/case/${c.id}/doc/${it.ref}`); };
    if(q('rmItem')) q('rmItem').onclick=()=>{ if(!confirm('إزالة هذه البطاقة وروابطها من اللوحة؟')) return; B.items=B.items.filter(x=>x.id!==it.id); B.links=B.links.filter(l=>l.a!==it.id&&l.b!==it.id); sel=null; touch(c.id); drawPins(); drawSide(); };
    if(q('lkLabel')) q('lkLabel').oninput=e=>{ lk.label=e.target.value; touch(c.id); drawLines(); };
    if(q('rmLink')) q('rmLink').onclick=()=>{ B.links=B.links.filter(l=>l.id!==lk.id); selLink=null; touch(c.id); drawLines(); drawSide(); };
    $$('[data-add]',s).forEach(b=> b.onclick=()=>{ addBoardDoc(c,i,b.dataset.add); drawPins(); drawSide(); });
    q('addFree').onclick=()=>{ const t=q('freeNew').value.trim(); if(!t){ toast('اكتب نص البطاقة'); return; } const n=B.items.length; B.items.push({id:uid('bi'),kind:'free',label:t,x:60+(n%6)*190,y:60+Math.floor(n/6)*150,cls:q('freeCls').value}); touch(c.id); drawPins(); drawSide(); };
  }
  applyZoom(); drawPins(); drawSide();
}

/* ---------- notes ---------- */
function refOptions(c, sel){ return `<option value="">بدون ربط</option>` + c.documents.map(d=>`<option value="${d.id}" ${sel===d.id?'selected':''}>${esc(d.no)} — ${esc(d.title)}</option>`).join(''); }
function secNotes(h,c,i){
  let q='';
  h.innerHTML = `<p class="hint">ملاحظاتك خاصة بك ومحفوظة في هذا المتصفح فقط.</p>
  <div class="card"><label for="nt">ملاحظة جديدة</label><textarea id="nt"></textarea><label for="nref">ربط بمستند</label><select id="nref">${refOptions(c)}</select><button class="btn" id="nadd" style="margin-top:8px">إضافة الملاحظة</button></div>
  <div class="toolbar" style="margin-top:14px"><input type="search" id="nq" placeholder="ابحث في ملاحظاتك" aria-label="بحث في الملاحظات"></div><div id="nl"></div>`;
  const draw=()=>{
    const list=i.notes.filter(n=>!q||n.text.toLowerCase().includes(q.toLowerCase()));
    $('#nl').innerHTML = list.length ? list.map(n=>`<div class="note-item" data-n="${n.id}"><div class="hint">آخر تعديل: ${fmtDT(n.updated)}</div>
      <textarea aria-label="نص الملاحظة">${esc(n.text)}</textarea>
      <div class="row"><select aria-label="المستند المرتبط">${refOptions(c,n.ref)}</select><button class="btn small ghost" data-del="${n.id}">حذف</button></div></div>`).join('') : `<div class="card"><p class="hint">${i.notes.length?'لا توجد ملاحظات مطابقة.':'لا توجد ملاحظات بعد.'}</p></div>`;
    $$('.note-item').forEach(el=>{ const n=i.notes.find(x=>x.id===el.dataset.n);
      $('textarea',el).oninput=e=>{ n.text=e.target.value; n.updated=Date.now(); $('.hint',el).textContent='آخر تعديل: '+fmtDT(n.updated); touch(c.id); };
      $('select',el).onchange=e=>{ n.ref=e.target.value; n.updated=Date.now(); touch(c.id); };
      $('[data-del]',el).onclick=()=>{ if(!confirm('حذف هذه الملاحظة؟')) return; i.notes=i.notes.filter(x=>x.id!==n.id); touch(c.id); draw(); };
    });
  };
  $('#nadd').onclick=()=>{ const t=$('#nt').value.trim(); if(!t){ toast('اكتب نص الملاحظة'); return; } i.notes.unshift({id:uid('note'),text:t,ref:$('#nref').value,created:Date.now(),updated:Date.now()}); $('#nt').value=''; touch(c.id); draw(); };
  $('#nq').oninput=e=>{ q=e.target.value; draw(); };
  draw();
}

/* ---------- hypotheses ---------- */
function docChecks(c, selected, name){
  return `<div class="list-check">${c.documents.map(d=>`<label><input type="checkbox" data-grp="${name}" value="${d.id}" ${selected.includes(d.id)?'checked':''}> ${esc(d.no)} — ${esc(d.title)}</label>`).join('')}</div>`;
}
const readChecks = (root,name)=> $$(`[data-grp="${name}"]`,root).filter(x=>x.checked).map(x=>x.value);
function secHyps(h,c,i){
  let cmp=[];
  h.innerHTML = `<div class="row"><button class="btn" id="hnew">فرضية جديدة</button><span class="hint">درجة الثقة رأيك الشخصي، وليست دليلًا على صحة الفرضية.</span></div><div id="hl" style="margin-top:12px"></div><div id="hc"></div>`;
  const draw=()=>{
    $('#hl').innerHTML = i.hyps.length ? i.hyps.map(x=>`<div class="hyp-item" data-h="${x.id}">
      <label>العنوان</label><input type="text" data-f="title" value="${esc(x.title)}">
      <label>الشرح</label><textarea data-f="text">${esc(x.text)}</textarea>
      <label>أدلة تدعمها</label>${docChecks(c,x.supporting,'s'+x.id)}
      <label>أدلة تتعارض معها</label>${docChecks(c,x.conflicting,'c'+x.id)}
      <label>أسئلة لم تُحسم</label><textarea data-f="questions">${esc(x.questions)}</textarea>
      <label>درجة ثقتك: <span data-cv>${x.confidence}</span>%</label><input type="range" min="0" max="100" data-f="confidence" value="${x.confidence}">
      <label>الحالة</label><select data-f="status">${Object.entries(HSTATUS).map(([k,l])=>`<option value="${k}" ${x.status===k?'selected':''}>${l}</option>`).join('')}</select>
      <div class="row" style="margin-top:8px"><label style="margin:0"><input type="checkbox" data-cmp ${cmp.includes(x.id)?'checked':''}> للمقارنة</label><span class="spacer"></span><button class="btn small ghost" data-del>حذف</button></div></div>`).join('') : '<div class="card"><p class="hint">لم تسجّل أي فرضية بعد.</p></div>';
    $$('.hyp-item').forEach(el=>{ const x=i.hyps.find(y=>y.id===el.dataset.h);
      $$('[data-f]',el).forEach(f=>{ const ev=f.tagName==='SELECT'?'onchange':'oninput'; f[ev]=e=>{ x[f.dataset.f]= f.dataset.f==='confidence'? +e.target.value : e.target.value; if(f.dataset.f==='confidence') $('[data-cv]',el).textContent=x.confidence; touch(c.id); }; });
      $$('input[type=checkbox][data-grp]',el).forEach(cb=> cb.onchange=()=>{ x.supporting=readChecks(el,'s'+x.id); x.conflicting=readChecks(el,'c'+x.id); touch(c.id); });
      $('[data-del]',el).onclick=()=>{ if(!confirm('حذف هذه الفرضية؟')) return; i.hyps=i.hyps.filter(y=>y.id!==x.id); cmp=cmp.filter(z=>z!==x.id); touch(c.id); draw(); };
      $('[data-cmp]',el).onchange=e=>{ if(e.target.checked){ cmp.push(x.id); if(cmp.length>2) cmp.shift(); } else cmp=cmp.filter(z=>z!==x.id); draw(); };
    });
    const sel=cmp.map(id=>i.hyps.find(y=>y.id===id)).filter(Boolean);
    $('#hc').innerHTML = sel.length===2 ? `<h3>مقارنة</h3><div class="grid">${sel.map(x=>`<div class="card"><h3>${esc(x.title||'(بلا عنوان)')}</h3><p>${esc(x.text)}</p><p><b>تدعمها:</b> ${x.supporting.map(d=>esc(docTitle(c,d))).join('، ')||'—'}</p><p><b>تتعارض معها:</b> ${x.conflicting.map(d=>esc(docTitle(c,d))).join('، ')||'—'}</p><p><b>ثقتك:</b> ${x.confidence}% · ${HSTATUS[x.status]}</p><p><b>أسئلة:</b> ${esc(x.questions)||'—'}</p></div>`).join('')}</div>` : (sel.length===1?'<p class="hint">اختر فرضية ثانية للمقارنة.</p>':'');
  };
  $('#hnew').onclick=()=>{ i.hyps.unshift({id:uid('hyp'),title:'',text:'',supporting:[],conflicting:[],questions:'',confidence:50,status:'investigating',created:Date.now()}); touch(c.id); draw(); };
  draw();
}

/* ---------- timeline ---------- */
function timelineConflicts(list){
  const out=[]; const withT = list.map((e,idx)=>({e,idx})).filter(x=>x.e.time);
  for(let k=1;k<withT.length;k++){
    const a=withT[k-1], b=withT[k];
    if((a.e.date||'')===(b.e.date||'') && b.e.time < a.e.time){
      out.push({idx:b.idx, msg:`الحدث رقم ${b.idx+1} مسجّل الساعة ${b.e.time} وقد وُضع بعد الحدث رقم ${a.idx+1} المسجّل الساعة ${a.e.time} في اليوم نفسه (${a.e.date||'بلا تاريخ'}). قد يكون الترتيب مقصودًا (مثل عبور منتصف الليل أو اختلاف التاريخ)، لذا تأكد من حقل التاريخ.`});
    }
  }
  return out;
}
function secTimeline(h,c,i){
  h.innerHTML = `<div class="row"><button class="btn" id="tadd">إضافة حدث</button><span class="hint">اترك الوقت فارغًا إن كان مجهولًا؛ لن يُحوَّل إلى وقت محدد.</span></div><div id="tl" style="margin-top:12px"></div>`;
  const refreshFlags=()=>{
    const conf = timelineConflicts(i.timeline);
    $$('[data-t]').forEach((el,idx)=>{ const e=i.timeline[idx]; if(!e) return;
      const b=$('[data-badge]',el); b.textContent=CERT[e.certainty]; b.className='tag '+(e.certainty==='confirmed'?'blue':e.certainty==='unknown'?'red':'gold');
      $('[data-flags]',el).innerHTML = conf.filter(x=>x.idx===idx).map(x=>`<div class="warn" role="alert" style="margin-top:8px">⚠ تعارض محتمل في التسلسل: ${esc(x.msg)}</div>`).join(''); });
  };
  const draw=()=>{
    $('#tl').innerHTML = i.timeline.length ? i.timeline.map((e,idx)=>`<div class="hyp-item" data-t="${e.id}">
      <div class="row"><b>الحدث ${idx+1}</b> <span class="tag ${e.certainty==='confirmed'?'blue':e.certainty==='unknown'?'red':'gold'}" data-badge>${CERT[e.certainty]}</span><span class="spacer"></span>
      <button class="btn small ghost" data-up ${idx===0?'disabled':''} aria-label="تحريك للأعلى">↑</button><button class="btn small ghost" data-dn ${idx===i.timeline.length-1?'disabled':''} aria-label="تحريك للأسفل">↓</button><button class="btn small ghost" data-del>حذف</button></div>
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))"><div><label>التاريخ (نص حر)</label><input type="text" data-f="date" value="${esc(e.date)}" placeholder="مثال: 12 مارس"></div>
      <div><label>الوقت (اختياري)</label><input type="time" data-f="time" value="${esc(e.time)}"></div>
      <div><label>درجة اليقين</label><select data-f="certainty">${Object.entries(CERT).map(([k,l])=>`<option value="${k}" ${e.certainty===k?'selected':''}>${l}</option>`).join('')}</select></div></div>
      <label>وصف الحدث</label><textarea data-f="text">${esc(e.text)}</textarea>
      <label>المصدر</label><input type="text" data-f="source" value="${esc(e.source)}" placeholder="مثال: مستند 3">
      <details><summary>الأدلة المرتبطة (${e.docs.length})</summary>${docChecks(c,e.docs,'t'+e.id)}</details>
      <label>ملاحظات خاصة</label><textarea data-f="notes">${esc(e.notes)}</textarea>
      <div data-flags></div></div>`).join('') : '<div class="card"><p class="hint">لم تضف أحداثًا بعد.</p></div>';
    $$('[data-t]').forEach(el=>{ const idx=i.timeline.findIndex(x=>x.id===el.dataset.t), e=i.timeline[idx];
      $$('[data-f]',el).forEach(f=>{ const isChg = f.tagName==='SELECT'||f.type==='time'||f.dataset.f==='date'; f[isChg?'onchange':'oninput']=ev=>{ e[f.dataset.f]=ev.target.value; touch(c.id); if(isChg) refreshFlags(); }; });
      $$('input[type=checkbox][data-grp]',el).forEach(cb=> cb.onchange=()=>{ e.docs=readChecks(el,'t'+e.id); touch(c.id); });
      $('[data-up]',el).onclick=()=>{ if(idx>0){ [i.timeline[idx-1],i.timeline[idx]]=[i.timeline[idx],i.timeline[idx-1]]; touch(c.id); draw(); } };
      $('[data-dn]',el).onclick=()=>{ if(idx<i.timeline.length-1){ [i.timeline[idx+1],i.timeline[idx]]=[i.timeline[idx],i.timeline[idx+1]]; touch(c.id); draw(); } };
      $('[data-del]',el).onclick=()=>{ if(!confirm('حذف هذا الحدث؟')) return; i.timeline.splice(idx,1); touch(c.id); draw(); };
    });
    refreshFlags();
  };
  $('#tadd').onclick=()=>{ i.timeline.push({id:uid('ev'),date:'',time:'',certainty:'unknown',text:'',docs:[],source:'',notes:''}); touch(c.id); draw(); };
  draw();
}

/* ---------- final report ---------- */
function reportHTML(c,r,meta){
  const list = a => a.length ? '<ul>'+a.map(d=>`<li>${esc(docTitle(c,d))}</li>`).join('')+'</ul>' : '<p>—</p>';
  const sus = (c.suspects.find(s=>s.id===r.suspect)||{}).name || (r.suspect==='none'?'لا ينطبق / غير محدد':'—');
  return `<div class="paper" style="white-space:normal"><div class="doc-meta">${esc(c.number)} — ${esc(c.title)}${meta?' · '+esc(meta):''}</div><h3>تقرير التحقيق</h3>
  <h4>الاستنتاج الرئيسي</h4><p>${esc(r.conclusion)||'—'}</p><h4>المسؤول المحتمل</h4><p>${esc(sus)}</p>
  <h4>الأدلة الداعمة</h4>${list(r.supporting)}<h4>الأدلة المتعارضة</h4>${list(r.conflicting)}
  <h4>إعادة بناء التسلسل الزمني</h4><p style="white-space:pre-wrap">${esc(r.timeline)||'—'}</p>
  <h4>تفسير الأحداث</h4><p style="white-space:pre-wrap">${esc(r.explanation)||'—'}</p>
  <h4>أسئلة لم تُحسم</h4><p style="white-space:pre-wrap">${esc(r.questions)||'—'}</p>
  <h4>درجة الثقة</h4><p>${r.confidence}% (تقدير المحقق)</p><h4>ملاحظات إضافية</h4><p style="white-space:pre-wrap">${esc(r.observations)||'—'}</p></div>`;
}
function secReport(h,c,i){
  const R = i.report; let mode='edit';
  const draw=()=>{
    const subs = R.submissions;
    const hist = subs.length ? `<h3>سجل التسليمات</h3>${subs.map(s=>`<div class="note-item"><b>النسخة ${s.n}</b> — ${fmtDT(s.at)} — <span class="tag blue">مُسلَّمة</span> <button class="btn small ghost" data-view="${s.id}">عرض</button> <button class="btn small ghost" data-rev="${s.id}">فتح للمراجعة كمسودة جديدة</button></div>`).join('')}<div class="warn">تم استلام تقريرك. لا يتوفر لهذه القضية نظام تقييم معتمد، لذلك لم يُتحقق من صحة الاستنتاج ولا تُعرض درجة.</div>` : '';
    if(mode==='preview'){
      h.innerHTML = `${reportHTML(c,R.draft,'معاينة المسودة')}<div class="row" style="margin-top:12px"><button class="btn ghost" id="rEdit">العودة للتعديل</button><button class="btn" id="rSubmit">تسليم التقرير النهائي</button></div><div id="rErr"></div>${hist}`;
      $('#rEdit').onclick=()=>{ mode='edit'; draw(); }; $('#rSubmit').onclick=submit;
    } else {
      const r=R.draft;
      h.innerHTML = `${R.draft.basedOn?`<div class="warn">هذه مسودة جديدة مبنية على النسخة ${R.draft.basedOn}. النسخ المُسلَّمة السابقة محفوظة ولن تتغير.</div>`:''}
      <div class="card"><label>1. الاستنتاج الرئيسي</label><textarea data-f="conclusion">${esc(r.conclusion)}</textarea>
      <label>2. المسؤول المحتمل (إن كان ينطبق)</label><select data-f="suspect"><option value="">— لم يُحدَّد —</option>${c.suspects.map(s=>`<option value="${s.id}" ${r.suspect===s.id?'selected':''}>${esc(s.name)} — ${esc(s.role)}</option>`).join('')}<option value="none" ${r.suspect==='none'?'selected':''}>لا ينطبق / لا يمكن تحديده</option></select>
      <label>3. الأدلة الداعمة</label>${docChecks(c,r.supporting,'rs')}
      <label>4. الأدلة المتعارضة</label>${docChecks(c,r.conflicting,'rc')}
      <label>5. إعادة بناء التسلسل الزمني</label><textarea data-f="timeline">${esc(r.timeline)}</textarea><button class="btn small ghost" id="impTl" style="margin-top:6px">استيراد من جدولي الزمني</button>
      <label>6. تفسير الأحداث</label><textarea data-f="explanation">${esc(r.explanation)}</textarea>
      <label>7. أسئلة لم تُحسم</label><textarea data-f="questions">${esc(r.questions)}</textarea>
      <label>8. درجة الثقة: <span id="cv">${r.confidence}</span>%</label><input type="range" min="0" max="100" data-f="confidence" value="${r.confidence}">
      <label>9. ملاحظات إضافية</label><textarea data-f="observations">${esc(r.observations)}</textarea>
      <div class="row" style="margin-top:12px"><button class="btn ghost" id="rSave">حفظ المسودة</button><button class="btn" id="rPrev">معاينة التقرير</button></div></div>${hist}`;
      $$('[data-f]',h).forEach(f=>{ f[f.tagName==='SELECT'?'onchange':'oninput']=e=>{ R.draft[f.dataset.f]= f.dataset.f==='confidence'? +e.target.value : e.target.value; if(f.dataset.f==='confidence') $('#cv').textContent=R.draft.confidence; touch(c.id); }; });
      $$('[data-grp]',h).forEach(cb=> cb.onchange=()=>{ R.draft.supporting=readChecks(h,'rs'); R.draft.conflicting=readChecks(h,'rc'); touch(c.id); });
      $('#impTl').onclick=()=>{ if(!i.timeline.length){ toast('جدولك الزمني فارغ'); return; } R.draft.timeline = i.timeline.map((e,k)=>`${k+1}. ${[e.date,e.time||'الوقت غير محدد'].filter(Boolean).join(' ')} (${CERT[e.certainty]}): ${e.text}${e.source?' — المصدر: '+e.source:''}`).join('\n'); touch(c.id); draw(); };
      $('#rSave').onclick=()=>{ touch(c.id); Store.flush() ? toast('تم حفظ المسودة') : 0; };
      $('#rPrev').onclick=()=>{ mode='preview'; draw(); };
    }
    $$('[data-view]',h).forEach(b=> b.onclick=()=>{ const s=subs.find(x=>x.id===b.dataset.view); h.innerHTML = `${reportHTML(c,s.data,'النسخة '+s.n+' — '+fmtDT(s.at))}<button class="btn" id="bk" style="margin-top:12px">رجوع</button>`; $('#bk').onclick=draw; });
    $$('[data-rev]',h).forEach(b=> b.onclick=()=>{ const s=subs.find(x=>x.id===b.dataset.rev); if(!confirm('سيحل هذا محل مسودتك الحالية بنسخة من التقرير المُسلَّم. النسخ المُسلَّمة تبقى محفوظة. المتابعة؟')) return; R.draft = Object.assign(clone(s.data),{basedOn:s.n}); touch(c.id); mode='edit'; draw(); });
  };
  function submit(){
    const r=R.draft, errs=[];
    if(!r.conclusion.trim()) errs.push('الاستنتاج الرئيسي مطلوب.');
    if(!r.explanation.trim()) errs.push('تفسير الأحداث مطلوب.');
    if(!r.supporting.length) errs.push('اختر دليلًا واحدًا على الأقل يدعم استنتاجك.');
    if(errs.length){ $('#rErr').innerHTML = `<div class="warn" role="alert">${errs.map(esc).join('<br>')}</div>`; return; }
    if(!confirm('تسليم التقرير النهائي؟ ستُحفظ هذه النسخة كما هي في سجل التسليمات، ويمكنك لاحقًا فتحها كمسودة جديدة دون تغيير النسخة المُسلَّمة.')) return;
    R.submissions.push({id:uid('sub'), n:R.submissions.length+1, at:Date.now(), status:'submitted', data:clone(r)});
    R.draft = Object.assign(clone(r),{basedOn:null}); mode='edit'; touch(c.id); Store.flush(); toast('تم تسليم التقرير'); draw();
  }
  draw();
}


/* ---------- STAGE 4: MULTIPLAYER ---------- */
let multiPoll = null;
function viewMulti(v){
  if(multiPoll){ clearInterval(multiPoll); multiPoll=null; }
  const cases=CASES();
  const sessions=Store.data.multiplayerSessions||(Store.data.multiplayerSessions={});
  const local=sessions.local||null;
  v.innerHTML=`<div class="row" style="align-items:center;gap:12px;flex-wrap:wrap"><div><div class="hint">CASE ZERO / MULTIPLAYER</div><h2>التحقيق الجماعي</h2></div><span class="tag blue">تعاوني وتنافسي</span></div>
  <p class="hint">أنشئ جلسة محلية على الجهاز نفسه، أو استخدم جلسة عبر الإنترنت بعد إعداد قاعدة بيانات Supabase في الاستضافة.</p>
  <div class="grid">
    <section class="card"><h3>جلسة على الجهاز نفسه</h3><p>تناوبوا على الجهاز. يمكن استخدام الجلسة للتعاون أو المنافسة. إخفاء المعلومات هنا ليس حماية مادية كاملة إذا كان الآخرون يستطيعون رؤية الشاشة.</p>
      <label for="mLocalCase">القضية</label><select id="mLocalCase">${cases.map(c=>`<option value="${esc(c.id)}">${esc(c.number)} — ${esc(c.title)}</option>`).join('')}</select>
      <label for="mLocalMode">نمط اللعب</label><select id="mLocalMode"><option value="cooperative">تعاوني</option><option value="competitive">تنافسي</option></select>
      <label for="mLocalNames">أسماء اللاعبين (اسم في كل سطر، حتى 6)</label><textarea id="mLocalNames" rows="4" placeholder="محقق 1\nمحقق 2"></textarea>
      <button class="btn" id="mLocalCreate">إنشاء جلسة محلية</button></section>
    <section class="card"><h3>جلسة عبر الإنترنت</h3><p>تحتاج إعداد متغيرات Supabase ورفع مخطط قاعدة البيانات المرفق. لا تعمل المزامنة عبر الإنترنت قبل إكمال الإعداد.</p>
      <label for="mOnlineName">اسم المحقق</label><input id="mOnlineName" maxlength="40" placeholder="اسم العرض">
      <label for="mOnlineCode">رمز الجلسة للانضمام</label><input id="mOnlineCode" maxlength="12" placeholder="رمز منظم الجلسة">
      <div class="row"><button class="btn" id="mOnlineCreate">إنشاء جلسة</button><button class="btn ghost" id="mOnlineJoin">انضمام</button></div>
      <p class="hint" id="mOnlineStatus" aria-live="polite">الجلسات الخاصة تتطلب الرمز. لا تشارك رمز الجلسة إلا مع اللاعبين المدعوين.</p></section>
  </div>
  <section id="mWorkspace" class="card" style="margin-top:12px" ${local?'':'hidden'}></section>`;
  $('#mLocalCreate').onclick=()=>{
    const names=$('#mLocalNames').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).slice(0,6);
    if(names.length<2){toast('أدخل اسمَي لاعبين على الأقل');return;}
    const c=cases.find(x=>x.id===$('#mLocalCase').value); if(!c){toast('لا توجد قضية متاحة للجلسة');return;}
    sessions.local={id:uid('local_session'),caseId:c.id,mode:$('#mLocalMode').value,players:names.map((name,i)=>({id:uid('player'),name,role:i===0?'رئيس التحقيق':'محقق مشارك'})),turn:0,sharedNotes:'',chat:[],evidence:[],createdAt:Date.now()};
    Store.schedule(); renderLocalMulti();
  };
  $('#mOnlineCreate').onclick=()=>onlineMulti('create');
  $('#mOnlineJoin').onclick=()=>onlineMulti('join');
  if(local) renderLocalMulti();
  async function onlineMulti(action){
    const status=$('#mOnlineStatus'); const name=$('#mOnlineName').value.trim()||'محقق'; const code=$('#mOnlineCode').value.trim().toUpperCase();
    status.textContent='جارٍ الاتصال بالخادم…';
    try{
      const res=await fetch('/.netlify/functions/multiplayer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,name,code})});
      const data=await res.json(); if(!res.ok) throw new Error(data.error||'تعذر إكمال الطلب');
      const online=Store.data.onlineSessions||(Store.data.onlineSessions={}); online[data.code]={code:data.code,token:data.token,name}; Store.schedule();
      status.textContent=action==='create'?`تم إنشاء الجلسة. رمز الانضمام: ${data.code}`:`تم الانضمام إلى الجلسة ${data.code}.`;
      openOnline(data.code);
    }catch(e){status.textContent=`تعذر الاتصال: ${e.message}. تأكد من نشر Netlify Functions وإعداد SUPABASE_URL وSUPABASE_SERVICE_ROLE_KEY وإنشاء الجدول من ملف supabase-schema.sql.`;}
  }
  function renderLocalMulti(){
    const s=(Store.data.multiplayerSessions||{}).local; if(!s)return;
    const c=cases.find(x=>x.id===s.caseId); const box=$('#mWorkspace'); if(!box)return; box.hidden=false;
    box.innerHTML=`<div class="row"><div><div class="hint">جلسة محلية • ${s.mode==='cooperative'?'تعاونية':'تنافسية'}</div><h3>${esc(c?c.title:'قضية')}</h3></div><span class="spacer"></span><button class="btn ghost small" id="mLocalClose">إنهاء الجلسة</button></div>
      <div class="grid"><div><label>اللاعب الحالي</label><select id="mTurn">${s.players.map((p,i)=>`<option value="${i}" ${i===s.turn?'selected':''}>${esc(p.name)} — ${esc(p.role)}</option>`).join('')}</select><button class="btn" id="mNext">تسليم الدور للاعب التالي</button>
      <label for="mPrivateInfo">معلومة خاصة للاعب الحالي (محلية فقط)</label><textarea id="mPrivateInfo" rows="3" placeholder="اكتب معلومة ليطّلع عليها اللاعب الحالي فقط عند استخدام الجهاز بالتناوب"></textarea><button class="btn ghost" id="mShowPrivate">عرض المعلومة</button><div id="mPrivateOut" class="warn" hidden></div></div>
      <div><label for="mSharedNotes">ملاحظات التحقيق المشتركة</label><textarea id="mSharedNotes" rows="6" placeholder="سجّلوا الاستنتاجات المشتركة المدعومة بالأدلة">${esc(s.sharedNotes)}</textarea><button class="btn" id="mSaveShared">حفظ الملاحظات</button></div></div>
      <hr><h3>سجل النقاش</h3><div class="card" id="mChatLog">${s.chat.length?s.chat.map(x=>`<p><b>${esc(x.name)}:</b> ${esc(x.text)}</p>`).join(''):'<p class="hint">لا توجد رسائل بعد.</p>'}</div><div class="row"><input id="mChatText" maxlength="500" placeholder="اكتب ملاحظة للنقاش"><button class="btn" id="mChatSend">إرسال</button></div>
      <p class="hint">هذه الجلسة محفوظة محليًا على هذا الجهاز فقط. ليست جلسة إنترنت ولا توفر فصلًا آمنًا للمعلومات الخاصة.</p>`;
    $('#mTurn').onchange=e=>{s.turn=+e.target.value;Store.schedule();};
    $('#mNext').onclick=()=>{s.turn=(s.turn+1)%s.players.length;Store.schedule();renderLocalMulti();};
    $('#mSaveShared').onclick=()=>{s.sharedNotes=$('#mSharedNotes').value;Store.schedule();toast('تم حفظ الملاحظات المشتركة');};
    $('#mChatSend').onclick=()=>{const text=$('#mChatText').value.trim();if(!text)return;s.chat.push({name:s.players[s.turn].name,text,at:Date.now()});s.chat=s.chat.slice(-100);Store.schedule();renderLocalMulti();};
    $('#mShowPrivate').onclick=()=>{const out=$('#mPrivateOut');out.hidden=false;out.textContent=$('#mPrivateInfo').value.trim()||'لم تُكتب معلومة خاصة. امسح الشاشة قبل تسليم الجهاز.';};
    $('#mLocalClose').onclick=()=>{if(confirm('إنهاء الجلسة المحلية؟ ستظل محفوظة حتى تحذف بيانات المتصفح.')){delete sessions.local;Store.schedule();$('#mWorkspace').hidden=true;}};
  }
  async function openOnline(code){
    const box=$('#mWorkspace'); if(!box)return; const saved=(Store.data.onlineSessions||{})[code]; if(!saved)return; box.hidden=false;
    box.innerHTML=`<div class="row"><h3>جلسة عبر الإنترنت: ${esc(code)}</h3><span class="spacer"></span><button class="btn ghost small" id="mOnlineRefresh">تحديث الآن</button></div><p class="hint">رمز الجلسة: <b>${esc(code)}</b> — شاركه مع اللاعبين المدعوين.</p><div class="grid"><div><label for="mOnlineShared">الملاحظات المشتركة</label><textarea id="mOnlineShared" rows="6"></textarea><button class="btn" id="mOnlineSave">مزامنة الملاحظات</button></div><div><h4>اللاعبون</h4><div id="mOnlinePlayers" class="card"></div><h4>النقاش</h4><div id="mOnlineChat" class="card"></div><div class="row"><input id="mOnlineChatText" maxlength="500" placeholder="رسالة"><button class="btn" id="mOnlineChatSend">إرسال</button></div></div></div><p class="hint">المزامنة تتم عبر الخادم بعد إعداد Supabase. لا تضع بيانات شخصية حساسة في النقاش.</p>`;
    async function refresh(){try{const r=await fetch('/.netlify/functions/multiplayer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'read',code,token:saved.token})});const d=await r.json();if(!r.ok)throw new Error(d.error||'فشل التحديث');$('#mOnlineShared').value=d.session.sharedNotes||'';$('#mOnlinePlayers').innerHTML=(d.session.players||[]).map(p=>`<p>${esc(p.name)}${p.role==='host'?' — رئيس الجلسة':''}</p>`).join('');$('#mOnlineChat').innerHTML=(d.session.chat||[]).slice(-30).map(m=>`<p><b>${esc(m.name)}:</b> ${esc(m.text)}</p>`).join('')||'<p class="hint">لا توجد رسائل.</p>';}catch(e){$('#mOnlinePlayers').textContent=e.message;}}
    $('#mOnlineRefresh').onclick=refresh;
    $('#mOnlineSave').onclick=async()=>{try{const r=await fetch('/.netlify/functions/multiplayer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'update',code,token:saved.token,patch:{sharedNotes:$('#mOnlineShared').value}})});const d=await r.json();if(!r.ok)throw new Error(d.error||'فشل الحفظ');toast('تمت مزامنة الملاحظات');refresh();}catch(e){toast(e.message);}};
    $('#mOnlineChatSend').onclick=async()=>{const text=$('#mOnlineChatText').value.trim();if(!text)return;try{const r=await fetch('/.netlify/functions/multiplayer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'chat',code,token:saved.token,text})});const d=await r.json();if(!r.ok)throw new Error(d.error||'فشل الإرسال');$('#mOnlineChatText').value='';refresh();}catch(e){toast(e.message);}};
    await refresh(); multiPoll=setInterval(refresh,5000);
  }
}

/* ---------- profile & settings ---------- */
const RANKS = [[0,'محقق تحت التدريب'],[1,'محقق مساعد'],[3,'محقق'],[6,'محقق أول'],[10,'كبير المحققين'],[20,'رئيس وحدة التحقيق']];
function viewProfile(v){
  const invs = Object.values(Store.data.investigations);
  const done = invs.filter(i=>i.report.submissions.length).length;
  const rank = RANKS.filter(r=>done>=r[0]).pop()[1];
  const nextR = RANKS.find(r=>r[0]>done);
  v.innerHTML = `<h2>ملف المحقق</h2><div class="card"><label for="pn">اسم العرض</label><input type="text" id="pn" maxlength="30" value="${esc(Store.data.user.name)}"><p><b>الرتبة:</b> ${rank}</p>
  <p class="hint">معيار الرتبة الحالي: عدد القضايا التي سلّمت فيها تقريرًا (لا يعتمد على صحة الحل). ${nextR?`الرتبة التالية عند ${nextR[0]} قضايا.`:''}</p></div>
  <div class="card" style="margin-top:12px"><h3>إحصاءات فعلية</h3><p>تحقيقات بدأتها: ${invs.length} · تقارير مُسلَّمة: ${invs.reduce((a,i)=>a+i.report.submissions.length,0)} · قضايا مكتملة: ${done}</p></div>
  <div class="card" style="margin-top:12px"><h3>الأوسمة</h3><p class="hint">لم تُفعَّل الأوسمة بعد؛ تحتاج إلى نظام تقييم معتمد للقضايا (مرحلة لاحقة).</p></div>
  <div class="card" style="margin-top:12px"><h3>سجل التحقيقات</h3>${invs.length?`<table><tbody>${invs.sort((a,b)=>b.lastActivity-a.lastActivity).map(i=>{ const c=getCase(i.caseId); return c?`<tr><td>${esc(c.number)} ${esc(c.title)}</td><td>${STATUS_LABEL[caseStatus(c)]}</td><td>${fmtDT(i.lastActivity)}</td></tr>`:''; }).join('')}</tbody></table>`:'<p class="hint">لا يوجد سجل بعد.</p>'}</div>`;
  $('#pn').oninput=e=>{ Store.data.user.name = e.target.value.slice(0,30)||'محقق'; Store.schedule(); };
}
function viewSettings(v){
  const s=Store.data.settings;
  v.innerHTML = `<h2>الإعدادات</h2>
  <div class="card"><h3>المظهر</h3>
    <label for="sTheme">السمة</label><select id="sTheme" disabled><option value="dark" selected>داكن — هوية CASE ZERO</option></select><p class="hint">الوضع الداكن ثابت للحفاظ على هوية اللعبة وراحة القراءة.</p>
    <label for="sGlow">شدة الإضاءة الحمراء: <span id="gv">${s.glow}</span>%</label><input type="range" id="sGlow" min="0" max="100" value="${s.glow}">
    <label for="sFs">حجم النص: <span id="fv">${s.fs}</span> px</label><input type="range" id="sFs" min="14" max="24" value="${s.fs}">
    <label><input type="checkbox" id="sRm" ${s.reduceMotion?'checked':''}> تقليل الحركة</label>
    <label for="sCon">وضوح التباين</label><select id="sCon"><option value="normal" ${s.contrast==='normal'?'selected':''}>عادي</option><option value="high" ${s.contrast==='high'?'selected':''}>مرتفع</option></select></div>
  <div class="card" style="margin-top:12px"><h3>الحفظ</h3><p>الحفظ التلقائي: مفعّل دائمًا (بعد كل تغيير بنصف ثانية). آخر حفظ: ${Store.lastSaved?fmtDT(Store.lastSaved):'لم يحدث حفظ في هذه الجلسة'}.</p>
    <p class="hint">يُحفظ تقدمك في ذاكرة هذا المتصفح فقط على هذا الجهاز. لا توجد مزامنة بين الأجهزة ولا نسخة سحابية. مسح بيانات المتصفح سيحذف التحقيقات، فاستخدم التصدير للنسخ الاحتياطي.</p>
    <div class="row"><button class="btn" id="sExp">تصدير بياناتي (JSON)</button><button class="btn ghost" id="sImpBtn">استيراد نسخة احتياطية</button><input type="file" id="sImp" accept=".json,application/json" hidden><button class="btn ghost" id="sDel">حذف كل بياناتي</button></div>
  </div>
  <div class="card" style="margin-top:12px"><h3>الصوت</h3><p class="hint">مؤثرات الصوت غير منفَّذة في هذه النسخة.</p></div>`;
  const set=(k,val)=>{ s[k]=val; applySettings(); Store.schedule(); };
  $('#sTheme').onchange=()=>{ s.theme='dark'; applySettings(); Store.schedule(); };
  $('#sGlow').oninput=e=>{ $('#gv').textContent=e.target.value; set('glow',+e.target.value); };
  $('#sFs').oninput=e=>{ $('#fv').textContent=e.target.value; set('fs',+e.target.value); };
  $('#sRm').onchange=e=>set('reduceMotion',e.target.checked);
  $('#sCon').onchange=e=>set('contrast',e.target.value);
  $('#sExp').onclick=()=>{ Store.flush(); const blob=new Blob([JSON.stringify(Store.data,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='case-zero-backup.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); };
  $('#sImpBtn').onclick=()=>$('#sImp').click();
  $('#sImp').onchange=async e=>{ const file=e.target.files&&e.target.files[0]; if(!file) return; try{ const parsed=JSON.parse(await file.text()); if(!Store.valid(parsed) || !parsed.user || !parsed.settings || !parsed.investigations || typeof parsed.investigations!=='object') throw new Error('invalid'); if(!confirm('سيتم استبدال بيانات هذا المتصفح بالنسخة الاحتياطية المختارة. صدّر بياناتك الحالية أولًا إذا أردت الاحتفاظ بها. المتابعة؟')) return; const clean=clone(parsed); clean.settings=Object.assign(Store.defaults().settings,clean.settings,{theme:'dark'}); Store.data=clean; if(!Store.flush()) throw new Error('save'); applySettings(); toast('تم استيراد النسخة الاحتياطية'); go('/home'); }catch(err){ toast('تعذّر استيراد الملف. اختر نسخة CASE ZERO صحيحة بصيغة JSON.'); }finally{ e.target.value=''; } };
  $('#sDel').onclick=()=>{ if(!confirm('سيُحذف كل تقدمك وملاحظاتك وتقاريرك من هذا المتصفح نهائيًا. المتابعة؟')) return; localStorage.removeItem(Store.KEY); localStorage.removeItem(Store.PREV); Store.data=Store.defaults(); Store.flush(); applySettings(); toast('تم حذف البيانات'); go('/home'); };
}


/* ---------- CASE ZERO LAB (Netlify serverless backend required) ---------- */
function viewLab(v){
  const cases=CASES();
  v.innerHTML=`<div class="row" style="align-items:center;gap:12px;flex-wrap:wrap"><div><div class="hint">CASE ZERO / AUTHOR WORKSPACE</div><h2>مختبر القضية صفر</h2></div><span class="tag gold">أدوات المؤلف</span></div>
  <div class="warn">استخدم هذا القسم لتطوير القضايا فقط. يجب نشره مع Netlify Functions وإعداد متغيرات البيئة المطلوبة. كل طلب ذكاء اصطناعي قد يستهلك رصيد API. لا تضع مفتاح API داخل ملفات الموقع.</div>
  <div class="card" style="margin-top:12px"><h3>صلاحية المؤلف</h3><label for="labCode">رمز دخول أدوات المؤلف</label><input id="labCode" type="password" autocomplete="current-password" placeholder="أدخل رمز المؤلف الذي أعددته في الاستضافة"><p class="hint">لا يوجد تسجيل دخول مستخدمين في هذه النسخة؛ هذا رمز مشترك لحماية أدوات المختبر بشكل أولي.</p></div>
  <div class="grid" style="margin-top:12px">
    <section class="card"><h3>مراجعة قضية بالذكاء الاصطناعي</h3><p>مراجعة القضية مجانية من ناحية ميزة المنتج، لكنها تستهلك رصيد API الخاص بالمشروع. راجع ترابط الأدلة والتوقيتات والتناقضات وقابلية الحل؛ النتيجة مساعدة وليست ضمانًا للجودة.</p>
      <label for="labReviewCase">مصدر القضية</label><select id="labReviewCase"><option value="">أدخل نص القضية يدويًا</option>${cases.map(c=>`<option value="${esc(c.id)}">${esc(c.number)} — ${esc(c.title)}</option>`).join('')}</select>
      <label for="labReviewText">نص القضية أو الوثائق</label><textarea id="labReviewText" rows="8" placeholder="ألصق هنا وصف القضية والوثائق والأدلة والتوقيتات. لا تضع بيانات شخصية حقيقية."></textarea>
      <button class="btn" id="labReviewBtn">بدء المراجعة</button></section>
    <section class="card"><h3>إنشاء مسودة قضية — ميزة مدفوعة عند الإطلاق</h3><p>هذه النسخة تتيح للمؤلف إنشاء مسودة للاختبار. بوابة الدفع والتحقق من استحقاق كل مستخدم ليست مفعّلة بعد؛ لا تعتبر هذا الزر عملية شراء أو دفع حقيقية. يجب إعداد مزود دفع وتسجيل مستخدمين قبل الإطلاق التجاري.</p>
      <label for="labGenre">نوع القضية</label><select id="labGenre"><option>جريمة غامضة</option><option>اختفاء</option><option>سرقة معقدة</option><option>ابتزاز</option><option>احتيال</option></select>
      <label for="labDifficulty">مستوى الصعوبة</label><select id="labDifficulty"><option>متوسط</option><option>سهل</option><option>صعب</option><option>خبير</option></select>
      <label for="labTheme">الفكرة أو القيود</label><textarea id="labTheme" rows="5" placeholder="مثال: قصر قديم، 4 مشتبه بهم، جدول زمني متداخل، شفرة واحدة قابلة للحل."></textarea>
      <button class="btn" id="labCreateBtn">إنشاء مسودة</button></section>
  </div>
  <section class="card" id="labResultCard" style="margin-top:12px" hidden><div class="row"><h3>النتيجة</h3><span class="spacer"></span><button class="btn ghost small" id="labCopyBtn">تحديد النص للنسخ</button></div><pre id="labResult" style="white-space:pre-wrap;overflow-wrap:anywhere;font:inherit;line-height:1.8"></pre><p class="hint">النتيجة مسودة غير معتمدة. لا تنشرها قبل التحقق من الاتساق وإزالة أي أخطاء.</p></section>`;
  const reviewCase=$('#labReviewCase'), reviewText=$('#labReviewText');
  reviewCase.onchange=()=>{ const c=cases.find(x=>x.id===reviewCase.value); if(c) reviewText.value=JSON.stringify({number:c.number,title:c.title,description:c.description,difficulty:c.difficulty,category:c.category,documents:c.documents},null,2); };
  const run=async(action,extra,button)=>{
    const code=$('#labCode').value.trim();
    if(!code){toast('أدخل رمز المؤلف أولًا');$('#labCode').focus();return;}
    button.disabled=true; const old=button.textContent; button.textContent='جارٍ العمل…';
    const out=$('#labResultCard'); out.hidden=false; $('#labResult').textContent='جارٍ الاتصال بالخادم…';
    try{
      const res=await fetch('/.netlify/functions/case-lab',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,accessCode:code,...extra})});
      const data=await res.json().catch(()=>({error:'استجابة غير مفهومة من الخادم'}));
      if(!res.ok) throw new Error(data.error||`تعذر الطلب (${res.status})`);
      $('#labResult').textContent=data.result||'لم تُرجع الخدمة نتيجة.';
    }catch(err){ $('#labResult').textContent='تعذر تشغيل مختبر الذكاء الاصطناعي. '+err.message+'\n\nتأكد من نشر المشروع باستخدام Netlify Functions وإعداد OPENAI_API_KEY وCASE_LAB_ACCESS_CODE في متغيرات البيئة، ثم أعد النشر.'; }
    finally{button.disabled=false;button.textContent=old;}
  };
  $('#labReviewBtn').onclick=()=>{const text=reviewText.value.trim();if(!text){toast('أدخل نص القضية أو اختر قضية من القائمة');return;}if(text.length>24000){toast('النص طويل جدًا؛ اختصره إلى أقل من 24 ألف حرف');return;}run('review',{caseText:text},$('#labReviewBtn'));};
  $('#labCreateBtn').onclick=()=>{const theme=$('#labTheme').value.trim();run('create',{genre:$('#labGenre').value,difficulty:$('#labDifficulty').value,theme},$('#labCreateBtn'));};
  $('#labCopyBtn').onclick=()=>{const el=$('#labResult');const r=document.createRange();r.selectNodeContents(el);const sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);toast('تم تحديد النتيجة؛ اضغط Ctrl+C للنسخ');};
}

/* ---------- boot ---------- */
function startApp(){
  $('#logoSm').innerHTML = LOGO; $('#brandBtn').onclick=()=>go('/home');
  window.addEventListener('hashchange',()=>{ if(ctx.cleanup){ ctx.cleanup(); ctx.cleanup=null; } const m=location.hash.match(/#\/case\/[^/]+\/([^/]+)/); const nextSec=m?m[1]:null; if(nextSec && nextSec!=='doc') ctx.prevSec=nextSec; ctx.curSec=nextSec; route(); });
  window.addEventListener('beforeunload',()=>{ if(Store.dirty) Store.flush(); });
  document.addEventListener('visibilitychange',()=>{ if(document.hidden && Store.dirty) Store.flush(); });
  route();
}
function boot(){
  const st = Store.load(); applySettings();
  if(st==='recovered') setTimeout(()=>toast('تعذّر قراءة آخر حفظ، تمت استعادة النسخة السابقة.'),500);
  setSave(Store.lastSaved?'saved':'x'); $('#saveInd').textContent = 'الحفظ المحلي مفعّل';
  if(!Store.data.introSeen){
    const intro=$('#intro'); intro.hidden=false; $('#introLogo').innerHTML=LOGO;
    const done=()=>{ intro.hidden=true; Store.data.introSeen=true; Store.schedule(); clearTimeout(t); };
    const t=setTimeout(done, 3200); $('#skipIntro').onclick=done;
  }
  startApp();
}
document.addEventListener('DOMContentLoaded', boot);
window.__CZ = {Store, caseStatus, timelineConflicts}; // test hook
})();
