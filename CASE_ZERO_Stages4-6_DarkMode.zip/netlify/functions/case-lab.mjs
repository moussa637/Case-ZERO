const json = (statusCode, payload) => new Response(JSON.stringify(payload), {
  status: statusCode,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
});

export default async (request) => {
  if (request.method !== "POST") return json(405, { error: "الطريقة غير مسموحة." });
  const apiKey = process.env.OPENAI_API_KEY;
  const accessCode = process.env.CASE_LAB_ACCESS_CODE;
  if (!apiKey || !accessCode) return json(503, { error: "لم يتم إعداد مفاتيح الخدمة في الاستضافة بعد." });

  let body;
  try { body = await request.json(); } catch { return json(400, { error: "بيانات الطلب غير صالحة." }); }
  if (!body || typeof body !== "object") return json(400, { error: "بيانات الطلب غير صالحة." });
  if (typeof body.accessCode !== "string" || body.accessCode.length > 200 || body.accessCode !== accessCode) {
    return json(401, { error: "رمز المؤلف غير صحيح." });
  }

  const action = body.action;
  let instructions;
  if (action === "review") {
    const caseText = typeof body.caseText === "string" ? body.caseText.trim() : "";
    if (!caseText || caseText.length > 24000) return json(400, { error: "نص القضية مطلوب ويجب ألا يتجاوز 24 ألف حرف." });
    instructions = `أنت مراجع جودة لقضايا تحقيق خيالية لمنصة CASE ZERO. راجع المادة المقدمة فقط ولا تخترع أدلة غير موجودة. أخرج تقريرًا عربيًا منظمًا بالعناوين: 1) ملخص الاتساق 2) التناقضات الزمنية 3) تعارض الشهادات 4) الأدلة الناقصة 5) الألغاز وقابلية الحل 6) هل يوجد حل واحد مدعوم أم عدة حلول؟ 7) تعديلات مقترحة. فرّق بوضوح بين ما يثبته النص وما هو مجرد احتمال. لا تدّعِ التحقق من حقائق غير موجودة. المادة:\n\n${caseText}`;
  } else if (action === "create") {
    const genre = String(body.genre || "جريمة غامضة").slice(0, 100);
    const difficulty = String(body.difficulty || "متوسط").slice(0, 50);
    const theme = String(body.theme || "").slice(0, 3000);
    instructions = `أنشئ مسودة قضية تحقيق خيالية أصلية باللغة العربية لمنصة CASE ZERO. النوع: ${genre}. الصعوبة: ${difficulty}. قيود المستخدم: ${theme || "لا توجد قيود إضافية"}. أخرج أقسامًا واضحة: عنوان ورقم مؤقت، مقدمة بلا حرق، خلفية المحقق، قائمة المشتبه بهم ودوافعهم، تسلسل زمني، قائمة المستندات والأدلة الخام، أقوال الشهود، أسئلة مفتوحة للمحقق، ثم في النهاية قسم منفصل بعنوان سري للغاية — حل المؤلف. يجب أن يعتمد الحل على الأدلة المذكورة، وأن تبيّن كيف يستبعد الأدلة البدائل الأخرى. لا تخلط الحل السري مع المستندات المخصصة للاعب. لا تستخدم بيانات أشخاص حقيقيين. هذه مسودة وليست قضية معتمدة.`;
  } else {
    return json(400, { error: "نوع العملية غير معروف." });
  }

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4.1-mini", input: instructions, max_output_tokens: action === "create" ? 6500 : 3500 }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const status = response.status === 429 ? 429 : 502;
      return json(status, { error: response.status === 429 ? "وصل الطلب إلى حد الاستخدام أو الرصيد المتاح. راجع حساب API." : "تعذر على خدمة الذكاء الاصطناعي معالجة الطلب. راجع إعدادات API وسجلات الدالة." });
    }
    const result = (data.output || []).flatMap(item => item.content || []).filter(part => part.type === "output_text").map(part => part.text).join("\n\n");
    if (!result) return json(502, { error: "لم تُرجع الخدمة نصًا صالحًا." });
    return json(200, { result });
  } catch {
    return json(502, { error: "تعذر الاتصال بخدمة الذكاء الاصطناعي." });
  }
};
