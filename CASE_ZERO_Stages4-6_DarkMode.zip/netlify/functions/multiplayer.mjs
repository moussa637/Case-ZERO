import { randomBytes } from 'node:crypto';
const json=(statusCode,payload)=>new Response(JSON.stringify(payload),{status:statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
const token=()=>randomBytes(32).toString('base64url');
const code=()=>randomBytes(5).toString('hex').slice(0,8).toUpperCase();
const cleanName=v=>String(v||'محقق').trim().replace(/[<>]/g,'').slice(0,40)||'محقق';
async function db(path,options={}){
 const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key) throw new Error('لم يتم إعداد قاعدة بيانات الجلسات.');
 const r=await fetch(`${url.replace(/\/$/,'')}/rest/v1/${path}`,{...options,headers:{apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json',Prefer:'return=representation',...(options.headers||{})}});
 const text=await r.text(); let data; try{data=text?JSON.parse(text):null}catch{data=null;}
 if(!r.ok) throw new Error(r.status===404||r.status===400?'تعذر الوصول إلى جدول الجلسات. نفّذ ملف supabase-schema.sql وتأكد من إعدادات Supabase.':'تعذر حفظ بيانات الجلسة.');
 return data;
}
async function findSession(codeValue){
 const rows=await db(`case_zero_sessions?session_code=eq.${encodeURIComponent(codeValue)}&select=session_code,data,updated_at&limit=1`);
 return rows?.[0]||null;
}
function authorized(session,memberToken){return !!(session&&typeof memberToken==='string'&&session.data?.players?.some(p=>p.token===memberToken));}
export default async request=>{
 if(request.method!=='POST') return json(405,{error:'الطريقة غير مسموحة.'});
 let b; try{b=await request.json()}catch{return json(400,{error:'بيانات الطلب غير صالحة.'});}
 if(!b||typeof b!=='object') return json(400,{error:'بيانات الطلب غير صالحة.'});
 const action=String(b.action||'');
 try{
  if(action==='create'){
   let sessionCode=code(); for(let i=0;i<4&&await findSession(sessionCode);i++) sessionCode=code();
   const memberToken=token();
   const data={mode:'cooperative',sharedNotes:'',chat:[],players:[{id:randomBytes(8).toString('hex'),name:cleanName(b.name),role:'host',token:memberToken}],createdAt:new Date().toISOString()};
   await db('case_zero_sessions',{method:'POST',body:JSON.stringify({session_code:sessionCode,data,updated_at:new Date().toISOString()})});
   return json(200,{code:sessionCode,token:memberToken,session:{...data,players:data.players.map(({token,...p})=>p)}});
  }
  const sessionCode=String(b.code||'').toUpperCase().replace(/[^A-F0-9]/g,'').slice(0,8);
  if(!/^[A-F0-9]{8}$/.test(sessionCode)) return json(400,{error:'رمز الجلسة غير صالح.'});
  let session=await findSession(sessionCode);
  if(action==='join'){
   if(!session) return json(404,{error:'لم يتم العثور على الجلسة. تحقق من الرمز.'});
   if(session.data.players.length>=6) return json(409,{error:'وصلت الجلسة إلى الحد الأقصى وهو 6 لاعبين.'});
   const memberToken=token(); session.data.players.push({id:randomBytes(8).toString('hex'),name:cleanName(b.name),role:'member',token:memberToken});
   await db(`case_zero_sessions?session_code=eq.${sessionCode}`,{method:'PATCH',body:JSON.stringify({data:session.data,updated_at:new Date().toISOString()})});
   return json(200,{code:sessionCode,token:memberToken,session:{...session.data,players:session.data.players.map(({token,...p})=>p)}});
  }
  if(!session) return json(404,{error:'لم يتم العثور على الجلسة.'});
  if(!authorized(session,b.token)) return json(401,{error:'صلاحية الجلسة غير صحيحة. أعد الانضمام باستخدام الرمز.'});
  if(action==='read'){
   const safe={...session.data,players:session.data.players.map(({token,...p})=>p)};
   return json(200,{code:sessionCode,session:safe,updatedAt:session.updated_at});
  }
  if(action==='update'){
   const patch=b.patch&&typeof b.patch==='object'?b.patch:{};
   if(typeof patch.sharedNotes==='string') session.data.sharedNotes=patch.sharedNotes.slice(0,12000);
   await db(`case_zero_sessions?session_code=eq.${sessionCode}`,{method:'PATCH',body:JSON.stringify({data:session.data,updated_at:new Date().toISOString()})});
   return json(200,{ok:true});
  }
  if(action==='chat'){
   const text=String(b.text||'').trim(); if(!text||text.length>500)return json(400,{error:'الرسالة فارغة أو أطول من المسموح.'});
   const player=session.data.players.find(p=>p.token===b.token); session.data.chat.push({name:player.name,text,at:new Date().toISOString()}); session.data.chat=session.data.chat.slice(-100);
   await db(`case_zero_sessions?session_code=eq.${sessionCode}`,{method:'PATCH',body:JSON.stringify({data:session.data,updated_at:new Date().toISOString()})});
   return json(200,{ok:true});
  }
  return json(400,{error:'نوع العملية غير معروف.'});
 }catch(e){return json(503,{error:e.message||'تعذر تشغيل نظام الجلسات. راجع إعدادات الخادم.'});}
};
