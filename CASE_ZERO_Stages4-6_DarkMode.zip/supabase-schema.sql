-- CASE ZERO multiplayer session storage
-- Run this in the Supabase SQL Editor. The service-role key is used ONLY in Netlify server functions.
create table if not exists public.case_zero_sessions (
  session_code text primary key check (session_code ~ '^[A-F0-9]{8}$'),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create index if not exists case_zero_sessions_updated_at_idx on public.case_zero_sessions(updated_at);
alter table public.case_zero_sessions enable row level security;
-- Intentionally create no anon/authenticated policies. All access is mediated by the Netlify function using the server-side service role.
