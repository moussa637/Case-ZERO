# CASE ZERO | القضية صفر — Stages 2–6 release candidate

Arabic RTL, dark-mode-first investigation application with local investigations, local multiplayer, a Supabase-backed online session endpoint, and a Netlify/OpenAI author lab.

## Local preview

```bash
cd public
python3 -m http.server 8000
```

Open `http://localhost:8000`. Individual investigations and same-device multiplayer work locally. Netlify Functions (AI Lab and online multiplayer) will not run through Python's static server.

## Publish to Netlify

Use a Git-connected Netlify deployment or Netlify CLI. **A drag-and-drop static deployment will not run the serverless functions.**

1. Upload this project folder to a private GitHub repository. Never commit API keys, `.env` files, Supabase service-role keys, or author access codes.
2. Import the repository in Netlify. `netlify.toml` sets `public` as the publish directory and `netlify/functions` as the functions directory.
3. Add environment variables in Netlify:
   - `OPENAI_API_KEY` — newly created OpenAI API key.
   - `CASE_LAB_ACCESS_CODE` — long random author-only secret.
   - `OPENAI_MODEL` — optional, defaults to `gpt-4.1-mini`.
   - `SUPABASE_URL` — Supabase project URL.
   - `SUPABASE_SERVICE_ROLE_KEY` — Supabase service-role key; server-side only.
4. In Supabase SQL Editor, run `supabase-schema.sql`.
5. Redeploy after setting environment variables.

## Stage 4: multiplayer

- Local same-device sessions for 2–6 players, cooperative or competitive.
- Online create/join using session codes, member tokens, shared notes, chat, and polling.
- Online mode requires Supabase and the schema. It is a release-candidate foundation, not production-grade authentication. Read `STAGE_4_5_6_FINALIZATION.md` for limitations and hardening steps.

## Stage 5: AI Lab

The serverless function supports case review and draft case generation. The API key stays in Netlify environment variables. AI output is not guaranteed correct and all generated cases require human review. AI calls consume the project’s API balance. The shared author code is a basic gate, not user authentication or durable rate limiting.

## Stage 6: payments

Live payments and paid entitlements are **not enabled**. The app does not fake payment success. A production payment flow requires a provider, verified webhooks, user authentication, and a durable entitlement database. See `STAGE_4_5_6_FINALIZATION.md`.

## Privacy and storage

Individual case progress is stored in the current browser using localStorage; it is not cloud-synced. Online multiplayer stores shared session data in the configured Supabase table. Do not put sensitive personal information in session notes/chat. Never put secret solutions in player-facing JavaScript or JSON.
