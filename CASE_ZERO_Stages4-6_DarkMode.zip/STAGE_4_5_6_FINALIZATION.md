# CASE ZERO — Stages 4, 5, 6 and release readiness

## Stage 4 — Multiplayer

Implemented in this build:
- Local same-device sessions for 2–6 players, cooperative or competitive.
- Turn switching, shared investigation notes, local discussion log, and a private-information demonstration.
- Online session create/join, random session code, server-issued member token, shared notes, chat, and 5-second refresh polling.
- Online session storage through a Netlify Function and Supabase PostgREST; the Supabase service-role key stays server-side.
- SQL schema in `supabase-schema.sql`.

To enable online sessions:
1. Create a Supabase project.
2. Run `supabase-schema.sql` in its SQL Editor.
3. Add Netlify environment variables `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`.
4. Deploy from the repository with Netlify Functions enabled.

Current limitations: this is an initial session backend, not a complete identity system. Session tokens are bearer secrets stored in the browser; anyone who obtains one can act as that member. Updates use polling rather than realtime subscriptions, and simultaneous writes can overwrite one another. Do not use it for sensitive information or describe it as enterprise-grade security. Add real user authentication, rate limiting, conflict-safe database updates, expiry/cleanup, and monitoring before a public commercial launch.

## Stage 5 — AI Lab

Included:
- Netlify Function for AI case review and draft case creation.
- OpenAI key remains a server environment variable; it is not included in browser files.
- Input size checks, response handling, Arabic output instructions, and clear failure states.
- Case creation output is explicitly treated as an unapproved draft; confidential solution material must not be published to player-facing case files.

Required environment variables:
- `OPENAI_API_KEY` (create a new key; never use a key shared in a chat or commit it to Git).
- `CASE_LAB_ACCESS_CODE` (long random author-only secret).
- `OPENAI_MODEL` (optional; defaults to `gpt-4.1-mini`).

The AI Lab currently uses a shared author code. It does not yet have per-user quotas or durable rate limiting. API calls may incur charges. Review is free as a product feature but still consumes the project’s OpenAI API balance. Generated cases need human review and solvability testing.

## Stage 6 — Payments and entitlements

The code intentionally does **not** simulate a successful payment or unlock paid creation based on a client-side flag. A real checkout/entitlement implementation is not enabled in this release because it requires the chosen payment provider, merchant configuration, verified webhooks, user identity, and a durable entitlement store. Without those, a paywall could be bypassed or a legitimate buyer could lose access.

Before enabling paid case creation:
1. Select a payment provider available for the project owner’s country and business setup.
2. Implement real sign-in and server-side user identity.
3. Create checkout sessions on the server only.
4. Verify signed provider webhooks on the server.
5. Persist payment and entitlement records in the database.
6. Check entitlement server-side on every paid generation request.
7. Add refunds, failed-payment handling, usage limits, audit logs, and support flow.

No live payment is collected by this build. The AI creation button is an author-preview tool only, not a payment flow.

## Release checklist

- [ ] Deploy the repository through Netlify (drag-and-drop of the ZIP alone will not deploy serverless functions).
- [ ] Configure `OPENAI_API_KEY`, `CASE_LAB_ACCESS_CODE`, and optionally `OPENAI_MODEL`.
- [ ] Configure Supabase variables and run the SQL schema to enable online sessions.
- [ ] Test multiplayer with at least two separate browsers/devices.
- [ ] Add authentication, rate limits, session expiration, and conflict-safe writes before public multiplayer release.
- [ ] Configure payment provider and identity before offering paid creation.
- [ ] Test API usage, errors, backup/restore, mobile RTL, and production logs.
- [ ] Rotate any API key previously shared in a conversation.

## What is genuinely available without external configuration

- Individual case investigation and browser-local autosave.
- Local same-device multiplayer session workflow.
- Dark Arabic RTL interface.

Online multiplayer and AI features require their server environment variables. Cloud saves, user accounts, and real payments are not represented as complete until the corresponding services are configured and tested.
